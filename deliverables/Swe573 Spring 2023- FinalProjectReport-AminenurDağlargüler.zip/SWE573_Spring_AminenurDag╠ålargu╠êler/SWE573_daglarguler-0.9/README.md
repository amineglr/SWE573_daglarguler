# SWE573_daglarguler
Swe573 
